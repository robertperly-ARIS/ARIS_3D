import {Light} from "../../..";

export class ShadowMapViewer {
	constructor(light: Light)
}



