import {Object3D} from "../../..";

export class PLYExporter {
	constructor();

	parse(object: Object3D, onDone: (res: any) => void, options: object): null;
}
