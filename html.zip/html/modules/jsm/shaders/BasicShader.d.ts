import {
  Uniform
} from '../../../src/Three';

export interface BasicShader {
  uniforms: {};
  vertexShader: string;
  fragmentShader: string;
}
